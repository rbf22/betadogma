"""
I/O helpers for FASTA/VCF/Parquet/HDF5.
"""
def read_fasta(*args, **kwargs):
    pass

def read_vcf(*args, **kwargs):
    pass
