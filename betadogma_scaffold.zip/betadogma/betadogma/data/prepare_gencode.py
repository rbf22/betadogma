"""
Prepare GENCODE annotations into standardized training format.
"""
def run(output_path: str):
    """Parse GTF/GFF to exon/intron/CDS structures. Placeholder."""
    pass
