"""
Prepare GTEx short-read junction counts and isoform usage labels.
"""
def run(output_path: str):
    """Compute junction PSI and isoform abundance estimates. Placeholder."""
    pass
