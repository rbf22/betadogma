"""Isoform graph construction and decoding."""
