"""Hybrid NMD prediction: rules + learned model."""
