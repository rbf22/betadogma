"""Variant encoding and synthetic mutagenesis."""
