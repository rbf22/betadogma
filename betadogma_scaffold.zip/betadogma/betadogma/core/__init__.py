"""Core modules: encoder and per-base heads."""
