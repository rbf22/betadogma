"""
Loss functions for multi-task training:
- BCE for per-base classification
- KL divergence for ψ
- Consistency losses for NMD rule vs learned
"""
def bce_loss(*args, **kwargs):
    pass

def kl_loss(*args, **kwargs):
    pass
