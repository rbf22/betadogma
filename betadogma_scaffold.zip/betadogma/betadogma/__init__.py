"""
BetaDogma package initializer.
"""
from .model import BetaDogmaModel, preprocess_sequence, preprocess_variant
