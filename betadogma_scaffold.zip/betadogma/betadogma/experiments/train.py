"""
Multi-task training loop scaffold.
"""
def main(config_path: str = "experiments/config/default.yaml"):
    # TODO: load config, datasets, build model, train
    print("Training stub:", config_path)

if __name__ == "__main__":
    main()
