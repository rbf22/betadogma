def test_import():
    import betadogma
